from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
from flasgger import Swagger
import MetaTrader5 as mt5
import logging
import time
from datetime import datetime, timedelta
from threading import Lock, Semaphore
from collections import defaultdict
import os  # Import the os module
from database import init_db, store_strategy, update_strategy_end, store_trade, get_all_strategies, get_strategy_details, get_strategy_equity, update_strategy_name, DB_PATH
from werkzeug.exceptions import HTTPException
import sqlite3
import pytz
import re

app = Flask(__name__)
# Configure CORS properly
CORS(app, resources={
    r"/*": {
        "origins": "http://localhost:3000",
        "supports_credentials": True,
        "allow_headers": ["Content-Type", "Authorization"],
        "expose_headers": ["*"],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
    }
})
Swagger(app)

# Initialize database before first request
with app.app_context():
    init_db()
    print("✅ Database initialized successfully")

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Constants for timezone
# Remove timezone constants
# Remove IST = pytz.timezone('Asia/Kolkata')
# Remove UTC = pytz.UTC

# Remove timezone conversion functions
def convert_mt5_time_to_ist(mt5_timestamp):
    """Convert MT5 timestamp to datetime"""
    return datetime.fromtimestamp(mt5_timestamp)

def convert_to_ist(dt):
    """Convert any datetime to UTC"""
    return dt

# -----------------------------------------------------------------------------
# Global Note:
# Use actionType "CLOSE_ALL" in the webhook JSON payload to close all open positions.
# If a "symbol" is provided along with "CLOSE_ALL", then only positions for that symbol will be closed.
# -----------------------------------------------------------------------------

# Global lock for all MT5 interactions to avoid concurrent access issues.
mt5_lock = Lock()

# -----------------------------------------------------------------------------
# Global Parameters
# -----------------------------------------------------------------------------
MAX_OPEN_POSITIONS = 500
GLOBAL_WAITING_PERIOD = 30
SIGNAL_LOCK_ENABLED = False
DEVELOPMENT_MODE = 0 # 1 to enable development mode (simulated orders), 0 to disable (real orders)

# Add near the top with other global variables
current_strategy_id = None  # Global variable to track current strategy

# -----------------------------------------------------------------------------
# Account Parameters for Account 1 (Main Account)
# -----------------------------------------------------------------------------
ACCOUNT1_ENABLED = 1  # 1 to enable trading, 0 to disable
ACCOUNT1_NUMBER = 243517217
ACCOUNT1_PASSWORD = "Simran02$"
ACCOUNT1_SERVER = "Exness-MT5Trial14"  # Server URL for Account 1
ACCOUNT1_RISK_PERCENTAGE = 1.0
ACCOUNT1_PER_TRADE_RISK = 0.03
ACCOUNT1_RISK_MODE = 1
ACCOUNT1_ATR_MULTIPLIER_SL = 1.5
ACCOUNT1_ATR_MULTIPLIER_TP = 1.95
ACCOUNT1_MT5_PATH = r"C:\Program Files\MetaTrader 5 EXNESS\terminal64.exe"
ACCOUNT1_HEDGE_ENABLED = 0
ACCOUNT1_NAME = "Account 1 (Main)"
ACCOUNT1_CUSTOM_SYMBOL_ENABLED = 1  # 1 to enable custom symbol for Account 1, 0 to disable
ACCOUNT1_CUSTOM_SYMBOL_NAME = "BTCUSDm" # Custom symbol name for Account 1

# -----------------------------------------------------------------------------
# Account Parameters for Account 2 (Hedge Account)
# -----------------------------------------------------------------------------
ACCOUNT2_ENABLED = 1  # 0 to disable trading
ACCOUNT2_NUMBER = 147283
ACCOUNT2_PASSWORD = "9+375U6g9k"
ACCOUNT2_SERVER = "FusionMarkets-Demo" # Server URL for Account 2
ACCOUNT2_RISK_PERCENTAGE = 1.0
ACCOUNT2_PER_TRADE_RISK = 0.03
ACCOUNT2_RISK_MODE = 1
ACCOUNT2_ATR_MULTIPLIER_SL = 1.5
ACCOUNT2_ATR_MULTIPLIER_TP = 1.95
ACCOUNT2_MT5_PATH = r"C:\Program Files\Fusion Markets MetaTrader 5\terminal64.exe"
ACCOUNT2_HEDGE_ENABLED = 1
ACCOUNT2_NAME = "Account 2 (Hedge)"
ACCOUNT2_CUSTOM_SYMBOL_ENABLED = 1  # 1 to enable custom symbol for Account 2, 0 to disable
ACCOUNT2_CUSTOM_SYMBOL_NAME = "BTCUSD" # Custom symbol name for Account 2 (can be same as webhook symbol or different)


# -----------------------------------------------------------------------------
# Global Signal Locking Settings
# -----------------------------------------------------------------------------


# Lock for managing the global last processed time.
time_lock = Lock()
global_last_processed = time.time() - GLOBAL_WAITING_PERIOD
global_semaphore = Semaphore(1)

# -----------------------------------------------------------------------------
# Logging configuration - UPDATED LOGGING SETUP
# -----------------------------------------------------------------------------
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

# General log (for webhook requests, general info)
general_log_handler = logging.FileHandler('general_log.txt')
general_log_handler.setFormatter(log_formatter)
general_logger = logging.getLogger('general_logger')
general_logger.setLevel(logging.INFO)
general_logger.addHandler(general_log_handler)

# Terminal log (for MT5 initialization, login, terminal errors)
terminal_log_handler = logging.FileHandler('terminal_log.txt')
terminal_log_handler.setFormatter(log_formatter)
terminal_logger = logging.getLogger('terminal_logger')
terminal_logger.setLevel(logging.ERROR) # Or logging.INFO for more detail
terminal_logger.addHandler(terminal_log_handler)

# Orders log (for order placement, execution, errors related to trading)
orders_log_handler = logging.FileHandler('orders_log.txt')
orders_log_handler.setFormatter(log_formatter)
orders_logger = logging.getLogger('orders_logger')
orders_logger.setLevel(logging.INFO)
orders_logger.addHandler(orders_log_handler)

# Webhook log (separate file to log every webhook request received)
webhook_log_handler = logging.FileHandler('webhook_log.txt')
webhook_log_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s')) # Simpler format for webhook log
webhook_logger = logging.getLogger('webhook_logger')
webhook_logger.setLevel(logging.INFO)
webhook_logger.addHandler(webhook_log_handler)


# -----------------------------------------------------------------------------
# Webhook request counter - for /webhooklog endpoint
# -----------------------------------------------------------------------------
webhook_counts = defaultdict(int)

# -----------------------------------------------------------------------------
# Utility Functions (These are now NOT USED by endpoint functions directly)
# -----------------------------------------------------------------------------
def initialize_mt5(mt5_path): # Kept for potential other uses or reference
    if not mt5.initialize(path=mt5_path):
        terminal_logger.error("Initialize() failed, error code = %s", mt5.last_error()) # Log to terminal_logger
        return False
    return True

def login_mt5(account, password, server): # Kept for potential other uses or reference
    authorized = mt5.login(account, password=password, server=server)
    if not authorized:
        terminal_logger.error("Login failed for account %s, error code = %s", account, mt5.last_error()) # Log to terminal_logger
        return False
    return True

def get_account_info_mt5(): # Kept for potential other uses or reference
    info = mt5.account_info()
    if info is None:
        terminal_logger.error("Failed to fetch account info, error code = %s", mt5.last_error()) # Log to terminal_logger
        return None
    return info

def get_tick_data(symbol): # Kept for potential other uses or reference
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        terminal_logger.error("Failed to get tick data for symbol %s, error code = %s", symbol, mt5.last_error()) # Log to terminal_logger
        return None
    return tick

def calculate_volume_from_risk(risk_amount, stop_loss, entry_price): # Kept for potential other uses or reference
    distance = abs(entry_price - stop_loss)
    if distance == 0:
        return 0
    volume = risk_amount / distance
    volume /= 100
    min_volume = 0.01
    max_volume = 1.0
    volume = max(min_volume, min(volume, max_volume))
    return round(volume, 2)

def check_open_positions(): # Kept for potential other uses or reference
    total = mt5.positions_total()
    general_logger.info("Total open positions: %s", total) # Log to general_logger
    return total < MAX_OPEN_POSITIONS

def place_order(action_type, symbol, volume, stop_loss, take_profit, comment, risk_amount, risk_percentage, account_number):
    tick = get_tick_data(symbol)
    if tick is None:
        return None

    spread = round(tick.ask - tick.bid, 2)
    price = tick.bid if action_type == "ORDER_TYPE_SELL" else tick.ask
    deviation = 20
    order_type = mt5.ORDER_TYPE_SELL if action_type == "ORDER_TYPE_SELL" else mt5.ORDER_TYPE_BUY

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": symbol,
        "volume": volume,
        "type": order_type,
        "price": price,
        "sl": stop_loss,
        "tp": take_profit,
        "deviation": deviation,
        "comment": comment,
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    order_start = time.time()

    if DEVELOPMENT_MODE == 1:
        # Simulated order placement
        orders_logger.info(f"[DEVELOPMENT MODE] Simulated Order for account {account_number}: {request}")
        result_code = mt5.TRADE_RETCODE_DONE  # Simulate success
        result_comment = "Simulated order in development mode"
        exec_time = time.time() - order_start
        result = type('SimulatedResult', (object,), {"retcode": result_code, "comment": result_comment})() # Create a dummy object mimicking result
    else:
        result = mt5.order_send(request)
        exec_time = time.time() - order_start

    if result.retcode != mt5.TRADE_RETCODE_DONE:
        orders_logger.error("Order failed for account %s, retcode=%s, comment=%s", account_number, result.retcode, result.comment)
        return {
            "status": "error",
            "retcode": result.retcode,
            "comment": result.comment,
            "spread": spread,
            "bid": round(tick.bid, 2),
            "ask": round(tick.ask, 2)
        }

    risk = abs(price - stop_loss)
    reward = abs(take_profit - price)
    rr = reward / risk if risk != 0 else None

    # Store trade in database if a strategy is running
    if current_strategy_id is not None:
        store_trade(
            strategy_id=current_strategy_id,
            account_number=account_number,
            ticket=result.order,  # Use order ID from result
            symbol=symbol,
            trade_type=action_type,
            volume=volume,
            price=price,
            profit=0,  # Initial profit is 0
            trade_time=datetime.now()
        )

    response = {
        "message": "Order executed successfully" if DEVELOPMENT_MODE == 0 else "[DEVELOPMENT MODE] Order simulated successfully",
        "status": "success",
        "current_equity": None,
        "bid": round(tick.bid, 2),
        "ask": round(tick.ask, 2),
        "spread": spread,
        "calculated_volume": volume,
        "max_loss": round(risk_amount, 2),
        "entry_price": round(price, 2),
        "stop_loss": round(stop_loss, 2),
        "take_profit": round(take_profit, 2),
        "risk_to_reward": round(rr, 2) if rr is not None else None,
        "execution_time": round(exec_time, 4),
        "risk_per_trade_percentage": risk_percentage * 100,
        "trade_execution_time": datetime.now().isoformat(),
        "account_number": account_number,
        "development_mode": DEVELOPMENT_MODE
    }
    if DEVELOPMENT_MODE == 0:
        orders_logger.info("Order placed for account %s: %s", account_number, request)
    else:
        orders_logger.info("[DEVELOPMENT MODE] Simulated order response for account %s: %s", account_number, response)

    return response

def close_positions(symbol=None):
    """
    Close positions with improved error handling and race condition prevention.
    Args:
        symbol (str, optional): Symbol to close positions for. If None, closes all positions.
    Returns:
        dict: Results of closing operations with detailed status
    """
    results = {
        "status": "processing",
        "message": "Processing close positions request",
        "results": [],
        "summary": {
            "total_positions": 0,
            "positions_to_close": 0,  # New counter for positions matching symbol filter
            "successfully_closed": 0,
            "failed_to_close": 0,
            "total_profit": 0
        }
    }

    try:
        # Initialize MT5 connection status tracking
        positions = mt5.positions_get()
        if positions is None:
            terminal_logger.error(f"Failed to retrieve positions, error code = {mt5.last_error()}")
            return {
                "status": "error",
                "message": "Failed to retrieve positions.",
                "error_code": mt5.last_error()
            }

        if len(positions) == 0:
            return {
                "status": "success",
                "message": "No open positions to close.",
                "results": []
            }

        # Count total positions and positions matching symbol filter
        results["summary"]["total_positions"] = len(positions)
        results["summary"]["positions_to_close"] = len([p for p in positions if symbol is None or p.symbol == symbol])
        
        if results["summary"]["positions_to_close"] == 0:
            return {
                "status": "success",
                "message": f"No positions found for symbol {symbol}",
                "results": []
            }

        orders_logger.info(f"Attempting to close {results['summary']['positions_to_close']} positions" + 
                         (f" for symbol {symbol}" if symbol else ""))
        
        for position in positions:
            # Skip if symbol doesn't match (when symbol is specified)
            if symbol is not None and position.symbol != symbol:
                continue

            close_result = {
                "symbol": position.symbol,
                "ticket": position.ticket,
                "volume": position.volume,
                "type": "buy" if position.type == mt5.POSITION_TYPE_SELL else "sell",
                "entry_price": position.price_open,
                "current_profit": position.profit,
                "status": "processing"
            }

            try:
                # Determine closing order type
                close_type = mt5.ORDER_TYPE_SELL if position.type == mt5.POSITION_TYPE_BUY else mt5.ORDER_TYPE_BUY
                
                # Get current price for closing
                tick = mt5.symbol_info_tick(position.symbol)
                if tick is None:
                    raise Exception(f"Failed to get tick data for {position.symbol}")
                
                close_price = tick.bid if close_type == mt5.ORDER_TYPE_SELL else tick.ask

                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "symbol": position.symbol,
                    "volume": position.volume,
                    "type": close_type,
                    "position": position.ticket,
                    "price": close_price,
                    "deviation": 20,
                    "magic": 234000,
                    "comment": "Close position by webhook",
                    "type_time": mt5.ORDER_TIME_GTC,
                    "type_filling": mt5.ORDER_FILLING_IOC,
                }

                # Add retry mechanism for closing positions
                max_retries = 3
                retry_delay = 1  # seconds
                success = False
                
                for attempt in range(max_retries):
                    if DEVELOPMENT_MODE == 1:
                        # Simulate successful close in development mode
                        close_result.update({
                            "status": "closed",
                            "close_price": close_price,
                            "profit": position.profit,
                            "development_mode": True
                        })
                        success = True
                        break
                    else:
                        # Real trading mode
                        result = mt5.order_send(request)
                        
                        if result and result.retcode == mt5.TRADE_RETCODE_DONE:
                            close_result.update({
                                "status": "closed",
                                "close_price": close_price,
                                "profit": position.profit,
                                "development_mode": False
                            })
                            success = True
                            break
                        elif attempt < max_retries - 1:
                            # Log retry attempt
                            orders_logger.warning(f"Retry {attempt + 1}/{max_retries} closing position {position.ticket} for {position.symbol}")
                            time.sleep(retry_delay)
                        else:
                            # Failed after all retries
                            error_code = result.retcode if result else mt5.last_error()
                            close_result.update({
                                "status": "error",
                                "error_code": error_code,
                                "error_message": f"Failed to close after {max_retries} attempts. Error code: {error_code}"
                            })

                if success:
                    results["summary"]["successfully_closed"] += 1
                    results["summary"]["total_profit"] += position.profit
                    
                    # Store trade in database if a strategy is running
                    if current_strategy_id is not None:
                        store_trade(
                            strategy_id=current_strategy_id,
                            account_number=position.login,
                            ticket=position.ticket,
                            symbol=position.symbol,
                            trade_type="CLOSE",
                            volume=position.volume,
                            price=close_price,
                            profit=position.profit,
                            trade_time=datetime.now()
                        )
                else:
                    results["summary"]["failed_to_close"] += 1

            except Exception as e:
                close_result.update({
                    "status": "error",
                    "error_message": str(e)
                })
                results["summary"]["failed_to_close"] += 1
                orders_logger.error(f"Error closing position {position.ticket}: {str(e)}")

            results["results"].append(close_result)

        # Verify counts
        total_processed = results["summary"]["successfully_closed"] + results["summary"]["failed_to_close"]
        if total_processed != results["summary"]["positions_to_close"]:
            terminal_logger.error(f"Position count mismatch. Expected: {results['summary']['positions_to_close']}, Processed: {total_processed}")
            results["summary"]["positions_to_close"] = total_processed

        # Update final status
        if results["summary"]["failed_to_close"] == 0:
            results["status"] = "success"
            results["message"] = f"Successfully closed {results['summary']['successfully_closed']} positions"
        elif results["summary"]["successfully_closed"] == 0:
            results["status"] = "error"
            results["message"] = f"Failed to close {results['summary']['failed_to_close']} positions"
        else:
            results["status"] = "partial"
            results["message"] = f"Closed {results['summary']['successfully_closed']} positions, {results['summary']['failed_to_close']} failed"

    except Exception as e:
        terminal_logger.error(f"Critical error in close_positions: {str(e)}")
        results.update({
            "status": "error",
            "message": "Critical error while closing positions",
            "error": str(e)
        })

    orders_logger.info(f"Close positions operation completed. Status: {results['status']}, Message: {results['message']}")
    return results

def get_mt5_health(mt5_path):
    """Check MT5 terminal health and return connection status with ping time."""
    initialized = False
    try:
        if not mt5.initialize(path=mt5_path):
            terminal_logger.error(f"MT5 Initialize failed for path: {mt5_path}, error code = {mt5.last_error()}")
            return {"timestamp": str(datetime.now()), "status": "Initialization Failed", "ping": None, "error": mt5.last_error()}
        initialized = True
        terminal_info = mt5.terminal_info()
        if terminal_info:
            return {
                "timestamp": str(datetime.now()),
                "status": "Connected",
                "ping": terminal_info.ping_last,  # Ping in microseconds
                "broker": terminal_info.company  # Broker name
            }
        else:
            terminal_logger.error(f"Failed to get terminal info for path: {mt5_path}, error code = {mt5.last_error()}")
            return {"timestamp": str(datetime.now()), "status": "Terminal Info Failed", "ping": None, "error": mt5.last_error()}
    except Exception as e:
        terminal_logger.error(f"Exception during MT5 health check for path: {mt5_path}, error: {e}")
        return {"timestamp": str(datetime.now()), "status": "Error", "ping": None, "error": str(e)}
    finally:
        if initialized:
            mt5.shutdown()

def get_account_health(account_name, mt5_path):
    """Get health status for a specific account."""
    health_data = get_mt5_health(mt5_path)
    return {account_name: health_data}

# -----------------------------------------------------------------------------
# New Utility Functions for Tick Data for each account
# -----------------------------------------------------------------------------
def get_tick_data_account1(symbol):
    """Retrieve tick data for a symbol from Account 1's MT5."""
    with mt5_lock:
        if not mt5.initialize(path=ACCOUNT1_MT5_PATH):
            terminal_logger.error(f"MT5 Initialize failed for Account 1 in get_tick_data_account1: {mt5.last_error()}")
            return {"status": "error", "message": "MT5 Initialization failed for Account 1", "error": str(mt5.last_error())}
        if not mt5.login(ACCOUNT1_NUMBER, ACCOUNT1_PASSWORD, ACCOUNT1_SERVER):
            terminal_logger.error(f"Login failed for Account 1 in get_tick_data_account1: {mt5.last_error()}")
            mt5.shutdown()
            return {"status": "error", "message": "Login failed for Account 1", "error": str(mt5.last_error())}

        symbol_to_check = symbol
        if ACCOUNT1_CUSTOM_SYMBOL_ENABLED:
            symbol_to_check = ACCOUNT1_CUSTOM_SYMBOL_NAME

        tick = mt5.symbol_info_tick(symbol_to_check)
        mt5.shutdown()
        if tick is None:
            terminal_logger.error(f"Failed to get tick data for symbol {symbol_to_check} for Account 1: {mt5.last_error()}")
            return {"status": "error", "message": f"Failed to get tick data for symbol {symbol_to_check} for Account 1", "error": str(mt5.last_error())}
        return {"status": "success", "tick": tick._asdict()}

def get_tick_data_account2(symbol):
    """Retrieve tick data for a symbol from Account 2's MT5."""
    with mt5_lock:
        if not mt5.initialize(path=ACCOUNT2_MT5_PATH):
            terminal_logger.error(f"MT5 Initialize failed for Account 2 in get_tick_data_account2: {mt5.last_error()}")
            return {"status": "error", "message": "MT5 Initialization failed for Account 2", "error": str(mt5.last_error())}
        if not mt5.login(ACCOUNT2_NUMBER, ACCOUNT2_PASSWORD, ACCOUNT2_SERVER):
            terminal_logger.error(f"Login failed for Account 2 in get_tick_data_account2: {mt5.last_error()}")
            mt5.shutdown()
            return {"status": "error", "message": "Login failed for Account 2", "error": str(mt5.last_error())}

        symbol_to_check = symbol
        if ACCOUNT2_CUSTOM_SYMBOL_ENABLED:
            symbol_to_check = ACCOUNT2_CUSTOM_SYMBOL_NAME

        tick = mt5.symbol_info_tick(symbol_to_check)
        mt5.shutdown()
        if tick is None:
            terminal_logger.error(f"Failed to get tick data for symbol {symbol_to_check} for Account 2: {mt5.last_error()}")
            return {"status": "error", "message": f"Failed to get tick data for symbol {symbol_to_check} for Account 2", "error": str(mt5.last_error())}
        
        # Convert tick data to dictionary and adjust time
        tick_dict = tick._asdict()
        # Convert time to IST by subtracting 2 hours (7200 seconds) to compensate for the offset
        tick_dict['time'] = tick_dict['time'] - 7200
        return {"status": "success", "tick": tick_dict}


# -----------------------------------------------------------------------------
# New Tick Data Endpoints for Account 1 and Account 2
# -----------------------------------------------------------------------------
@app.route('/get_tick1/<symbol>', methods=['GET'])
def get_tick_endpoint_account1(symbol):
    """
    Endpoint to retrieve tick data for a symbol from Account 1.
    ---
    tags:
      - Tick Data
    summary: Retrieves the last tick data for a given symbol from Account 1's MT5 terminal.
    parameters:
      - name: symbol
        in: path
        required: true
        description: Trading symbol (e.g., EURUSD).
        type: string
    responses:
      200:
        description: Tick data for the symbol from Account 1.
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  description: Status of the request ("success" or "error").
                tick:
                  type: object
                  description: Tick data details.
                message:
                  type: string
                  description: Error message if status is "error".
                error:
                  type: string
                  description: Detailed error information if status is "error".
      400:
        description: Error retrieving tick data.
    """
    response = get_tick_data_account1(symbol)
    if response["status"] == "success":
        return jsonify(response), 200
    else:
        return jsonify(response), 400

@app.route('/get_tick2/<symbol>', methods=['GET'])
def get_tick_endpoint_account2(symbol):
    """
    Endpoint to retrieve tick data for a symbol from Account 2.
    ---
    tags:
      - Tick Data
    summary: Retrieves the last tick data for a given symbol from Account 2's MT5 terminal.
    parameters:
      - name: symbol
        in: path
        required: true
        description: Trading symbol (e.g., EURUSD).
        type: string
    responses:
      200:
        description: Tick data for the symbol from Account 2.
        content:
          application/json:
            schema:
              type: object
              properties:
                status:
                  type: string
                  description: Status of the request ("success" or "error").
                tick:
                  type: object
                  description: Tick data details.
                message:
                  type: string
                  description: Error message if status is "error".
                error:
                  type: string
                  description: Detailed error information if status is "error".
      400:
        description: Error retrieving tick data.
    """
    response = get_tick_data_account2(symbol)
    if response["status"] == "success":
        return jsonify(response), 200
    else:
        return jsonify(response), 400


# -----------------------------------------------------------------------------
# Webhook Endpoint -  INDEPENDENT CODE
# -----------------------------------------------------------------------------
@app.route('/webhook', methods=['POST'])
def webhook():
    """
    Webhook endpoint to receive trading signals and execute orders.
    ---
    tags:
      - Trading
    summary: Receives webhook signals and places/closes orders on MT5 accounts.
    requestBody:
      required: true
      content:
        application/json:
          schema:
            type: object
            properties:
              actionType:
                type: string
                description: Type of action (ORDER_TYPE_BUY, ORDER_TYPE_SELL, CLOSE_ALL).
                example: ORDER_TYPE_BUY
              symbol:
                type: string
                description: Trading symbol (e.g., EURUSD).
                example: EURUSD
              atr:
                type: number
                description: ATR value for SL/TP calculation.
                example: 0.001
              comment:
                type: string
                description: Order comment.
                example: Webhook Signal
            required:
              - actionType
              - symbol
              - atr
    responses:
      200:
        description: Order execution status and details.
        content:
          application/json:
            schema:
              type: object
              properties:
                account1_order:
                  type: object
                  description: Response for Account 1 order.
                account2_order:
                  type: object
                  description: Response for Account 2 order.
                calculation_summary:
                  type: array
                  items:
                    type: object
                    description: Summary of calculations for each account.
                total_processing_time:
                  type: number
                  description: Total processing time in seconds.
      429:
        description: Too Many Requests - Signal locking or processing limit exceeded.
    """
    start_time = time.time()
    data = request.json

    webhook_logger.info(f"Webhook received: {data}")

    webhook_action = data.get("actionType")
    symbol_webhook = data.get("symbol")
    atr = data.get("atr")
    comment = data.get("comment")

    final_response = {}
    calculation_summary = []

    # Early validation of account states
    if ACCOUNT1_ENABLED == 0 and ACCOUNT2_ENABLED == 0:
        return jsonify({
            "status": "error",
            "message": "Trading is paused by backend",
            "details": "All trading accounts are disabled",
            "account1_status": "disabled",
            "account2_status": "disabled"
        }), 400

    # Determine effective actions based on hedge settings
    if webhook_action == "CLOSE_ALL":
        effective_action1 = "CLOSE_ALL"
        effective_action2 = "CLOSE_ALL"
    else:
        effective_action1 = ("ORDER_TYPE_BUY" if webhook_action == "ORDER_TYPE_SELL"
                            else "ORDER_TYPE_SELL") if ACCOUNT1_HEDGE_ENABLED == 1 else webhook_action
        effective_action2 = ("ORDER_TYPE_BUY" if webhook_action == "ORDER_TYPE_SELL"
                            else "ORDER_TYPE_SELL") if ACCOUNT2_HEDGE_ENABLED == 1 else webhook_action

    # Process Account 1
    acc1_start = time.time()
    account1_response = {}

    if ACCOUNT1_ENABLED == 0:
        account1_response = {
            "status": "skipped",
            "message": "Trading is paused by backend",
            "details": "Account 1 trading is disabled",
            "account_number": ACCOUNT1_NUMBER,
            "development_mode": DEVELOPMENT_MODE
        }
        general_logger.info(f"Skipping Account 1 (trading disabled): Webhook signal for {symbol_webhook}")
    else:
        # Original Account 1 trading logic here
        symbol_account1 = symbol_webhook
        if ACCOUNT1_CUSTOM_SYMBOL_ENABLED:
            symbol_account1 = ACCOUNT1_CUSTOM_SYMBOL_NAME
            general_logger.info(f"Account 1: Custom symbol enabled. Overriding webhook symbol '{symbol_webhook}' with custom symbol '{symbol_account1}'.")

        with mt5_lock:
            if not initialize_mt5(ACCOUNT1_MT5_PATH):
                account1_response = {"status": "error", "message": "Failed to initialize MT5 for account 1"}
            elif not login_mt5(ACCOUNT1_NUMBER, ACCOUNT1_PASSWORD, ACCOUNT1_SERVER):
                account1_response = {"status": "error", "message": "Failed to login to account 1"}
            elif acc1_info := get_account_info_mt5(): # Use the renamed function here
                if effective_action1 == "CLOSE_ALL":
                    account1_response = close_positions(symbol=symbol_account1 if symbol_webhook else None) # Use account symbol for close if webhook symbol is not present in CLOSE_ALL
                elif check_open_positions():
                    if tick1 := get_tick_data(symbol_account1):
                        if ACCOUNT1_RISK_MODE == 1:
                            effective_base1 = acc1_info.equity * ACCOUNT1_RISK_PERCENTAGE
                            risk_mode_text1 = "dynamic"
                        else:
                            effective_base1 = acc1_info.balance * ACCOUNT1_RISK_PERCENTAGE
                            risk_mode_text1 = "fixed"

                        risk_amount1 = effective_base1 * ACCOUNT1_PER_TRADE_RISK

                        if effective_action1 == "ORDER_TYPE_SELL":
                            entry1 = tick1.bid
                            stop_loss1 = entry1 + (atr * ACCOUNT1_ATR_MULTIPLIER_SL)
                            take_profit1 = entry1 - (atr * ACCOUNT1_ATR_MULTIPLIER_TP)
                        else:
                            entry1 = tick1.ask
                            stop_loss1 = entry1 - (atr * ACCOUNT1_ATR_MULTIPLIER_SL)
                            take_profit1 = entry1 + (atr * ACCOUNT1_ATR_MULTIPLIER_TP)

                        volume1 = calculate_volume_from_risk(risk_amount1, stop_loss1, entry1)
                        order_resp1 = place_order(effective_action1, symbol_account1, volume1, stop_loss1, take_profit1,
                                                    comment, risk_amount1, ACCOUNT1_PER_TRADE_RISK, ACCOUNT1_NUMBER)
                        if order_resp1:
                            order_resp1["bid"] = round(tick1.bid, 2) if tick1 else None
                            order_resp1["ask"] = round(tick1.ask, 2) if tick1 else None
                            order_resp1["direction"] = "sell" if effective_action1 == "ORDER_TYPE_SELL" else "buy"
                            order_resp1["hedge_enabled"] = ACCOUNT1_HEDGE_ENABLED
                            order_resp1["webhook_direction"] = "sell" if webhook_action == "ORDER_TYPE_SELL" else "buy"
                            order_resp1["account_processing_time"] = round(time.time() - acc1_start, 2)
                            order_resp1["current_equity"] = round(acc1_info.equity, 2)
                            order_resp1["account_risk_percentage"] = ACCOUNT1_RISK_PERCENTAGE * 100
                            order_resp1["per_trade_risk_percentage"] = ACCOUNT1_PER_TRADE_RISK * 100
                            order_resp1["risk_mode"] = risk_mode_text1
                            order_resp1["margin"] = round(acc1_info.margin, 2)
                            order_resp1["margin_free"] = round(acc1_info.margin_free, 2)
                            order_resp1["margin_level"] = round(acc1_info.margin_level, 2)
                            order_resp1["development_mode"] = DEVELOPMENT_MODE # Add development mode to response
                        account1_response = order_resp1
                    else:
                        account1_response = {"status": "error", "message": f"Failed to get tick data for symbol {symbol_account1} for account 1"}
                else:
                    account1_response = {"status": "error", "message": "Maximum open positions reached for account 1"}
            else:
                account1_response = {"status": "error", "message": "Failed to fetch account 1 info"}

            if symbol_account1:
                if symbol_info_obj := mt5.symbol_info(symbol_account1):
                    account1_response["symbol"] = symbol_account1
                    account1_response["symbol_spec"] = {
                        "digits": symbol_info_obj.digits,
                        "tickSize": symbol_info_obj.point
                    }
            mt5.shutdown()

        final_response["account1_order"] = account1_response
        if account1_response and "status" in account1_response:
            summary1 = {
                "account": "Account1",
                "symbol": account1_response.get("symbol"),
                "symbol_spec": account1_response.get("symbol_spec"),
                "current_equity": account1_response.get("current_equity"),
                "margin": account1_response.get("margin"),
                "margin_free": account1_response.get("margin_free"),
                "margin_level": account1_response.get("margin_level"),
                "account_risk_percentage": account1_response.get("account_risk_percentage"),
                "per_trade_risk_percentage": account1_response.get("per_trade_risk_percentage"),
                "risk_mode": account1_response.get("risk_mode"),
                "webhook_direction": account1_response.get("webhook_direction"),
                "effective_direction": account1_response.get("direction"),
                "entry_price": account1_response.get("entry_price"),
                "stop_loss": account1_response.get("stop_loss"),
                "take_profit": account1_response.get("take_profit"),
                "max_loss": account1_response.get("max_loss"),
                "calculated_volume": account1_response.get("calculated_volume"),
                "risk_to_reward": account1_response.get("risk_to_reward"),
                "bid": account1_response.get("bid"),
                "ask": account1_response.get("ask"),
                "spread": account1_response.get("spread"),
                "development_mode": account1_response.get("development_mode") # Add to summary
            }
            calculation_summary.append(summary1)

    # Process Account 2
    acc2_start = time.time()
    account2_response = {}

    if ACCOUNT2_ENABLED == 0:
        account2_response = {
            "status": "skipped",
            "message": "Trading is paused by backend",
            "details": "Account 2 trading is disabled",
            "account_number": ACCOUNT2_NUMBER,
            "development_mode": DEVELOPMENT_MODE
        }
        general_logger.info(f"Skipping Account 2 (trading disabled): Webhook signal for {symbol_webhook}")
    else:
        # Original Account 2 trading logic here
        symbol_account2 = symbol_webhook
        if ACCOUNT2_CUSTOM_SYMBOL_ENABLED == 1:
            symbol_account2 = ACCOUNT2_CUSTOM_SYMBOL_NAME
            general_logger.info(f"Account 2: Custom symbol enabled. Overriding webhook symbol '{symbol_webhook}' with custom symbol '{symbol_account2}'.")
        else:
            symbol_account2 = symbol_webhook

        with mt5_lock:
            if not initialize_mt5(ACCOUNT2_MT5_PATH):
                account2_response = {"status": "error", "message": "Failed to initialize MT5 for account 2"}
            elif not login_mt5(ACCOUNT2_NUMBER, ACCOUNT2_PASSWORD, ACCOUNT2_SERVER):
                account2_response = {"status": "error", "message": "Failed to login to account 2"}
            elif acc2_info := get_account_info_mt5(): # Use the renamed function here
                if effective_action2 == "CLOSE_ALL":
                    account2_response = close_positions(symbol=symbol_account2 if symbol_webhook else None) # Use account symbol for close if webhook symbol is not present in CLOSE_ALL
                elif check_open_positions():
                    if tick2 := get_tick_data(symbol_account2):
                        if ACCOUNT2_RISK_MODE == 1:
                            effective_base2 = acc2_info.equity * ACCOUNT2_RISK_PERCENTAGE
                            risk_mode_text2 = "dynamic"
                        else:
                            effective_base2 = acc2_info.balance * ACCOUNT2_RISK_PERCENTAGE
                            risk_mode_text2 = "fixed"

                        risk_amount2 = effective_base2 * ACCOUNT2_PER_TRADE_RISK

                        if effective_action2 == "ORDER_TYPE_SELL":
                            entry2 = tick2.bid
                            stop_loss2 = entry2 + (atr * ACCOUNT2_ATR_MULTIPLIER_SL)
                            take_profit2 = entry2 - (atr * ACCOUNT2_ATR_MULTIPLIER_TP)
                        else:
                            entry2 = tick2.ask
                            stop_loss2 = entry2 - (atr * ACCOUNT2_ATR_MULTIPLIER_SL)
                            take_profit2 = entry2 + (atr * ACCOUNT2_ATR_MULTIPLIER_TP)

                        volume2 = calculate_volume_from_risk(risk_amount2, stop_loss2, entry2)
                        order_resp2 = place_order(effective_action2, symbol_account2, volume2, stop_loss2, take_profit2,
                                                    comment, risk_amount2, ACCOUNT2_PER_TRADE_RISK, ACCOUNT2_NUMBER)
                        if order_resp2:
                            order_resp2["bid"] = round(tick2.bid, 2) if tick2 else None
                            order_resp2["ask"] = round(tick2.ask, 2) if tick2 else None
                            order_resp2["direction"] = "sell" if effective_action2 == "ORDER_TYPE_SELL" else "buy"
                            order_resp2["hedge_enabled"] = ACCOUNT2_HEDGE_ENABLED
                            order_resp2["webhook_direction"] = "sell" if webhook_action == "ORDER_TYPE_SELL" else "buy"
                            order_resp2["account_processing_time"] = round(time.time() - acc2_start, 2)
                            order_resp2["current_equity"] = round(acc2_info.equity, 2)
                            order_resp2["account_risk_percentage"] = ACCOUNT2_RISK_PERCENTAGE * 100
                            order_resp2["per_trade_risk_percentage"] = ACCOUNT2_PER_TRADE_RISK * 100
                            order_resp2["risk_mode"] = risk_mode_text2
                            order_resp2["margin"] = round(acc2_info.margin, 2)
                            order_resp2["margin_free"] = round(acc2_info.margin_free, 2)
                            order_resp2["margin_level"] = round(acc2_info.margin_level, 2)
                            order_resp2["development_mode"] = DEVELOPMENT_MODE # Add development mode to response
                        account2_response = order_resp2
                    else:
                        account2_response = {"status": "error", "message": f"Failed to get tick data for symbol {symbol_account2} for account 2"}
                else:
                    account2_response = {"status": "error", "message": "Maximum open positions reached for account 2"}
            else:
                account2_response = {"status": "error", "message": "Failed to fetch account 2 info"}


            if symbol_account2:
                if symbol_info_obj := mt5.symbol_info(symbol_account2):
                    account2_response["symbol"] = symbol_account2
                    account2_response["symbol_spec"] = {
                        "digits": symbol_info_obj.digits,
                        "tickSize": symbol_info_obj.point
                    }
            mt5.shutdown()

        final_response["account2_order"] = account2_response
        if account2_response and "status" in account2_response:
            summary2 = {
                "account": "Account2",
                "symbol": account2_response.get("symbol"),
                "symbol_spec": account2_response.get("symbol_spec"),
                "current_equity": account2_response.get("current_equity"),
                "margin": account2_response.get("margin"),
                "margin_free": account2_response.get("margin_free"),
                "margin_level": account2_response.get("margin_level"),
                "account_risk_percentage": account2_response.get("account_risk_percentage"),
                "per_trade_risk_percentage": account2_response.get("per_trade_risk_percentage"),
                "risk_mode": account2_response.get("risk_mode"),
                "webhook_direction": account2_response.get("webhook_direction"),
                "effective_direction": account2_response.get("direction"),
                "entry_price": account2_response.get("entry_price"),
                "stop_loss": account2_response.get("stop_loss"),
                "take_profit": account2_response.get("take_profit"),
                "max_loss": account2_response.get("max_loss"),
                "calculated_volume": account1_response.get("calculated_volume"), # Corrected variable name
                "risk_to_reward": account1_response.get("risk_to_reward"), # Corrected variable name
                "bid": account1_response.get("bid"), # Corrected variable name
                "ask": account1_response.get("ask"), # Corrected variable name
                "spread": account1_response.get("spread"), # Corrected variable name
                "development_mode": account2_response.get("development_mode") # Add to summary
            }
            calculation_summary.append(summary2)

    final_response["calculation_summary"] = calculation_summary
    final_response["total_processing_time"] = round(time.time() - start_time, 2)
    final_response["development_mode_enabled"] = DEVELOPMENT_MODE
    final_response["trading_status"] = {
        "account1": "Trading is paused by backend" if ACCOUNT1_ENABLED == 0 else "active",
        "account2": "Trading is paused by backend" if ACCOUNT2_ENABLED == 0 else "active"
    }

    return jsonify(final_response), 200

# -----------------------------------------------------------------------------
# Webhook Log Endpoint - NEW ENDPOINT
# -----------------------------------------------------------------------------
@app.route('/webhooklog')
def webhook_log_endpoint():
    """
    Endpoint to retrieve webhook request statistics for different time periods.
    ---
    tags:
      - Monitoring
    summary: Returns webhook counts for today, yesterday, this week, last week, this month, and total.
    responses:
      200:
        description: Webhook statistics.
        content:
          application/json:
            schema:
              type: object
              properties:
                webhook_stats:
                  type: object
                  properties:
                    today:
                      type: integer
                      description: Number of webhooks received today
                    yesterday:
                      type: integer
                      description: Number of webhooks received yesterday
                    this_week:
                      type: integer
                      description: Number of webhooks received this week
                    last_week:
                      type: integer
                      description: Number of webhooks received last week
                    this_month:
                      type: integer
                      description: Number of webhooks received this month
                    total:
                      type: integer
                      description: Total number of webhooks received
    """
    try:
        # Initialize counters
        stats = {
            'today': 0,
            'yesterday': 0,
            'this_week': 0,
            'last_week': 0,
            'this_month': 0,
            'total': 0
        }

        # Get current date and time
        now = datetime.now()
        today = now.date()
        yesterday = today - timedelta(days=1)
        
        # Calculate week boundaries
        today_weekday = now.weekday()
        week_start = today - timedelta(days=today_weekday)
        last_week_start = week_start - timedelta(days=7)
        last_week_end = week_start - timedelta(days=1)
        
        # Calculate month boundaries
        month_start = today.replace(day=1)

        # Read and parse webhook log file
        log_pattern = re.compile(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) - (.+)')
        
        try:
            with open('webhook_log.txt', 'r') as file:
                for line in file:
                    match = log_pattern.match(line)
                    if match:
                        timestamp_str = match[1]
                        try:
                            # Parse the timestamp
                            timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S,%f')
                            log_date = timestamp.date()

                            # Update counters
                            stats['total'] += 1

                            if log_date == today:
                                stats['today'] += 1
                            
                            if log_date == yesterday:
                                stats['yesterday'] += 1
                            
                            if week_start <= log_date <= today:
                                stats['this_week'] += 1
                            
                            if last_week_start <= log_date <= last_week_end:
                                stats['last_week'] += 1
                            
                            if log_date >= month_start:
                                stats['this_month'] += 1

                        except ValueError as e:
                            logger.error(f"Error parsing timestamp: {e}")
                            continue
        except FileNotFoundError:
            logger.warning("Webhook log file not found")
            return jsonify({'webhook_stats': stats})
        except Exception as e:
            logger.error(f"Error reading webhook log file: {e}")
            return jsonify({'webhook_stats': stats})

        return jsonify({'webhook_stats': stats})

    except Exception as e:
        logger.exception("Error processing webhook statistics")
        return jsonify({
            'error': 'Failed to process webhook statistics',
            'message': str(e)
        }), 500

# -----------------------------------------------------------------------------
# Risk Parameters Endpoint - MAX_OPEN_POSITIONS already included
# -----------------------------------------------------------------------------
@app.route('/riskparameters')
def risk_parameters():
    """
    Endpoint to retrieve risk parameters configuration.
    ---
    tags:
      - Configuration
    summary: Returns the configured risk parameters for the trading system.
    responses:
      200:
        description: Risk parameters configuration.
        content:
          application/json:
            schema:
              type: object
              properties:
                global_settings:
                  type: object
                  description: Global risk settings.
                account_risk_settings:
                  type: object
                  description: Risk settings for each account.
    """
    response_data = {
        "global_settings": {
            "signal_lock_enabled": SIGNAL_LOCK_ENABLED,
            "global_waiting_period": GLOBAL_WAITING_PERIOD,
            "max_open_positions": MAX_OPEN_POSITIONS,
            "development_mode": DEVELOPMENT_MODE
        },
        "account_risk_settings": {
            "account1": {
                "account_number": ACCOUNT1_NUMBER,
                "server_url": ACCOUNT1_SERVER,
                "risk_percentage": ACCOUNT1_RISK_PERCENTAGE,
                "per_trade_risk": ACCOUNT1_PER_TRADE_RISK,
                "risk_mode": ACCOUNT1_RISK_MODE,
                "atr_multiplier_sl": ACCOUNT1_ATR_MULTIPLIER_SL,
                "atr_multiplier_tp": ACCOUNT1_ATR_MULTIPLIER_TP,
                "hedge_enabled": ACCOUNT1_HEDGE_ENABLED,
                "custom_symbol_enabled": ACCOUNT1_CUSTOM_SYMBOL_ENABLED,
                "custom_symbol_name": ACCOUNT1_CUSTOM_SYMBOL_NAME
            },
            "account2": {
                "account_number": ACCOUNT2_NUMBER,
                "server_url": ACCOUNT2_SERVER,
                "risk_percentage": ACCOUNT2_RISK_PERCENTAGE,
                "per_trade_risk": ACCOUNT2_PER_TRADE_RISK,
                "risk_mode": ACCOUNT2_RISK_MODE,
                "atr_multiplier_sl": ACCOUNT2_ATR_MULTIPLIER_SL,
                "atr_multiplier_tp": ACCOUNT2_ATR_MULTIPLIER_TP,
                "hedge_enabled": ACCOUNT2_HEDGE_ENABLED,
                "custom_symbol_enabled": ACCOUNT2_CUSTOM_SYMBOL_ENABLED,
                "custom_symbol_name": ACCOUNT2_CUSTOM_SYMBOL_NAME
            }
        }
    }
    return jsonify(response_data)

# -----------------------------------------------------------------------------
# Account Information Endpoint - No changes
# -----------------------------------------------------------------------------
@app.route('/accountinformation')
def account_information():
    """
    Endpoint to retrieve account information.
    ---
    tags:
      - Account Data
    summary: Returns detailed information for both MT5 trading accounts.
    responses:
      200:
        description: Account information.
        content:
          application/json:
            schema:
              type: object
              properties:
                account1:
                  type: object
                  description: Information for Account 1.
                account2:
                  type: object
                  description: Information for Account 2.
                account1_error:
                  type: string
                  description: Error message for Account 1 if retrieval fails.
                account2_error:
                  type: string
                  description: Error message for Account 2 if retrieval fails.
    """
    return jsonify(_get_account_information())

def _get_account_information(): # Refactored to a function for re-use if needed
    account_info_data = {}

    # --- Account 1 Information ---
    if not mt5.initialize(path=ACCOUNT1_MT5_PATH): # Inlined initialize_mt5
        account_info_data['account1_error'] = f"MT5 Initialization failed for Account 1: {mt5.last_error()}"
        terminal_logger.error(account_info_data['account1_error']) # Log to terminal_logger
    else:
        if not mt5.login(ACCOUNT1_NUMBER, password=ACCOUNT1_PASSWORD, server=ACCOUNT1_SERVER): # Inlined login_mt5
            account_info_data['account1_error'] = f"Login failed for Account 1: {mt5.last_error()}"
            terminal_logger.error(account_info_data['account1_error']) # Log to terminal_logger
        else:
            acc1_info = mt5.account_info() # Inlined get_account_info_mt5
            if acc1_info:
                account_info_data['account1'] = acc1_info._asdict()
            else:
                account_info_data['account1_error'] = "Failed to get account info for Account 1"
                terminal_logger.error(account_info_data['account1_error']) # Log to terminal_logger
        mt5.shutdown()

    # --- Account 2 Information ---
    if not mt5.initialize(path=ACCOUNT2_MT5_PATH): # Inlined initialize_mt5
        account_info_data['account2_error'] = f"MT5 Initialization failed for Account 2: {mt5.last_error()}"
        terminal_logger.error(account_info_data['account2_error']) # Log to terminal_logger
    else:
        if not mt5.login(ACCOUNT2_NUMBER, password=ACCOUNT2_PASSWORD, server=ACCOUNT2_SERVER): # Inlined login_mt5
            account_info_data['account2_error'] = f"Login failed for Account 2: {mt5.last_error()}"
            terminal_logger.error(account_info_data['account2_error']) # Log to terminal_logger
        else:
            acc2_info = mt5.account_info() # Inlined get_account_info_mt5
            if acc2_info:
                account_info_data['account2'] = acc2_info._asdict()
            else:
                account_info_data['account2_error'] = "Failed to get account info for Account 2"
                terminal_logger.error(account_info_data['account2_error']) # Log to terminal_logger
        mt5.shutdown()

    return account_info_data # Return dictionary, jsonify is done in endpoint

# -----------------------------------------------------------------------------
# Equity Stream Endpoint - INDEPENDENT CODE
# -----------------------------------------------------------------------------
@app.route('/equitystream')
def equity_stream():
    try:
        equity_data = {
            'timestamp': datetime.now().isoformat(),
            'account1_equity': None,
            'account2_equity': None,
            'account1_error': None,
            'account2_error': None
        }

        # --- Account 1 Equity ---
        try:
            if not mt5.initialize(path=ACCOUNT1_MT5_PATH):
                raise Exception(f"MT5 Init Failed: {mt5.last_error()}")
            
            if not mt5.login(ACCOUNT1_NUMBER, ACCOUNT1_PASSWORD, ACCOUNT1_SERVER):
                raise Exception(f"Login Failed: {mt5.last_error()}")
            
            acc1_info = mt5.account_info()
            if acc1_info:
                equity_data['account1_equity'] = round(acc1_info.equity, 2)
            else:
                raise Exception("Could not get account info")
                
        except Exception as e:
            equity_data['account1_error'] = str(e)
            logger.error(f"Account 1 Error: {str(e)}")
        finally:
            mt5.shutdown()

        # --- Account 2 Equity ---
        try:
            if not mt5.initialize(path=ACCOUNT2_MT5_PATH):
                raise Exception(f"MT5 Init Failed: {mt5.last_error()}")
            
            if not mt5.login(ACCOUNT2_NUMBER, ACCOUNT2_PASSWORD, ACCOUNT2_SERVER):
                raise Exception(f"Login Failed: {mt5.last_error()}")
            
            acc2_info = mt5.account_info()
            if acc2_info:
                equity_data['account2_equity'] = round(acc2_info.equity, 2)
            else:
                raise Exception("Could not get account info")
                
        except Exception as e:
            equity_data['account2_error'] = str(e)
            logger.error(f"Account 2 Error: {str(e)}")
        finally:
            mt5.shutdown()

        # Store equity data if we have valid values and a strategy is running
        if (current_strategy_id is not None and 
            equity_data['account1_equity'] is not None and 
            equity_data['account2_equity'] is not None):
            try:
                with sqlite3.connect(DB_PATH) as conn:
                    c = conn.cursor()
                    c.execute('''
                        INSERT INTO strategy_equity 
                        (strategy_id, timestamp, account1_equity, account2_equity)
                        VALUES (?, ?, ?, ?)
                    ''', (
                        current_strategy_id,
                        datetime.now(),
                        equity_data['account1_equity'],
                        equity_data['account2_equity']
                    ))
                    conn.commit()
            except Exception as e:
                logger.error(f"Database Error: {str(e)}")
                # Don't raise the error, just log it
                
        # Add strategy status to response
        equity_data['strategy_running'] = current_strategy_id is not None
        equity_data['strategy_id'] = current_strategy_id
                
        return jsonify(equity_data)

    except Exception as e:
        logger.exception("Critical equity stream error")
        return jsonify({
            'error': 'Server error',
            'message': str(e)
        }), 500

# -----------------------------------------------------------------------------
# Terminal Information Endpoint - INDEPENDENT CODE
# -----------------------------------------------------------------------------
@app.route('/terminal')
def terminal_endpoint():
    """
    Endpoint to retrieve terminal information for both MT5 instances.
    ---
    tags:
      - MT5 Terminal Data
    summary: Returns details about the MT5 terminals connected for each account.
    responses:
      200:
        description: Terminal information.
        content:
          application/json:
            schema:
              type: object
              properties:
                terminal_info_account1:
                  type: object
                  description: Terminal information for Account 1 MT5 instance.
                terminal_info_account2:
                  type: object
                  description: Terminal information for Account 2 MT5 instance.
                terminal_info_account1_error:
                  type: string
                  description: Error message if terminal info retrieval fails for Account 1.
                terminal_info_account2_error:
                  type: string
                  description: Error message if terminal info retrieval fails for Account 2.
    """
    terminal_data = {}

    # --- Account 1 Terminal Info ---
    if not mt5.initialize(path=ACCOUNT1_MT5_PATH): # Inlined initialize_mt5
        terminal_data['terminal_info_account1_error'] = f"MT5 Initialization failed for Account 1: {mt5.last_error()}"
        terminal_logger.error(terminal_data['terminal_info_account1_error']) # Log to terminal_logger
    else:
        terminal_info_acc1 = mt5.terminal_info() # Inlined get_terminal_info
        if terminal_info_acc1:
            terminal_data['terminal_info_account1'] = terminal_info_acc1._asdict()
        else:
            terminal_data['terminal_info_account1_error'] = "Failed to get terminal information for Account 1"
            terminal_logger.error(terminal_data['terminal_info_account1_error']) # Log to terminal_logger
        mt5.shutdown()

    # --- Account 2 Terminal Info ---
    if not mt5.initialize(path=ACCOUNT2_MT5_PATH): # Inlined initialize_mt5
        terminal_data['terminal_info_account2_error'] = f"MT5 Initialization failed for Account 2: {mt5.last_error()}"
        terminal_logger.error(terminal_data['terminal_info_account2_error']) # Log to terminal_logger
    else:
        terminal_info_acc2 = mt5.terminal_info() # Inlined get_terminal_info
        if terminal_info_acc2:
            terminal_data['terminal_info_account2'] = terminal_info_acc2._asdict()
        else:
            terminal_data['terminal_info_account2_error'] = "Failed to get terminal information for Account 2"
            terminal_logger.error(terminal_data['terminal_info_account2_error']) # Log to terminal_logger
        mt5.shutdown()

    return jsonify(terminal_data)

# -----------------------------------------------------------------------------
# Open Positions Endpoint - INDEPENDENT CODE
# -----------------------------------------------------------------------------
@app.route('/openposition')
def open_position_endpoint():
    """
    Endpoint to retrieve currently open positions for both accounts.
    ---
    tags:
      - Trading Data
    summary: Returns a list of open trading positions for both MT5 accounts.
    responses:
      200:
        description: Open positions data.
        content:
          application/json:
            schema:
              type: object
              properties:
                account1_positions:
                  type: array
                  items:
                    type: object
                    description: Open position details for Account 1.
                account2_positions:
                  type: array
                  items:
                    type: object
                    description: Open position details for Account 2.
                account1_positions_error:
                  type: string
                  description: Error message if open positions retrieval fails for Account 1.
                account2_positions_error:
                  type: string
                  description: Error message if open positions retrieval fails for Account 2.
    """
    open_positions_data = {}

    # --- Account 1 Open Positions ---
    if not mt5.initialize(path=ACCOUNT1_MT5_PATH): # Inlined initialize_mt5
        open_positions_data['account1_positions_error'] = f"MT5 Initialization failed for Account 1: {mt5.last_error()}"
        terminal_logger.error(open_positions_data['account1_positions_error']) # Log to terminal_logger
    else:
        if not mt5.login(ACCOUNT1_NUMBER, password=ACCOUNT1_PASSWORD, server=ACCOUNT1_SERVER): # Inlined login_mt5
            open_positions_data['account1_positions_error'] = f"Login failed for Account 1: {mt5.last_error()}"
            terminal_logger.error(open_positions_data['account1_positions_error']) # Log to terminal_logger
        else:
            positions_acc1 = mt5.positions_get() # Inlined positions_get
            if positions_acc1 is not None:
                if len(positions_acc1) > 0:
                    open_positions_data['account1_positions'] = [position._asdict() for position in positions_acc1]
                else:
                    open_positions_data['account1_positions'] = "No open positions found for Account 1"
            else:
                open_positions_data['account1_positions_error'] = f"Failed to get open positions for Account 1: {mt5.last_error()}"
                terminal_logger.error(open_positions_data['account1_positions_error']) # Log to terminal_logger
        mt5.shutdown()

    # --- Account 2 Open Positions ---
    if not mt5.initialize(path=ACCOUNT2_MT5_PATH): # Inlined initialize_mt5
        open_positions_data['account2_positions_error'] = f"MT5 Initialization failed for Account 2: {mt5.last_error()}"
        terminal_logger.error(open_positions_data['account2_positions_error']) # Log to terminal_logger
    else:
        if not mt5.login(ACCOUNT2_NUMBER, password=ACCOUNT2_PASSWORD, server=ACCOUNT2_SERVER): # Inlined login_mt5
            open_positions_data['account2_positions_error'] = f"Login failed for Account 2: {mt5.last_error()}"
            terminal_logger.error(open_positions_data['account2_positions_error']) # Log to terminal_logger
        else:
            positions_acc2 = mt5.positions_get() # Inlined positions_get
            if positions_acc2 is not None:
                if len(positions_acc2) > 0:
                    open_positions_data['account2_positions'] = [position._asdict() for position in positions_acc2]
                else:
                    open_positions_data['account2_positions'] = "No open positions found for Account 2"
            else:
                open_positions_data['account2_positions_error'] = f"Failed to get open positions for Account 2: {mt5.last_error()}"
                terminal_logger.error(open_positions_data['account2_positions_error']) # Log to terminal_logger
        mt5.shutdown()

    return jsonify(open_positions_data)

# -----------------------------------------------------------------------------
# Position History Endpoint - INDEPENDENT CODE
# -----------------------------------------------------------------------------
@app.route('/positionhistory')
def position_history_endpoint():
    """
    Endpoint to retrieve historical trading positions for both accounts.
    """
    combined_history = {}

    # --- Account 1 History ---
    account1_history_data = {}
    if not mt5.initialize(path=ACCOUNT1_MT5_PATH):
        account1_history_data['error'] = f"Failed to connect to MT5 for {ACCOUNT1_NAME}"
        terminal_logger.error(account1_history_data['error'])
    elif not mt5.login(ACCOUNT1_NUMBER, ACCOUNT1_PASSWORD, ACCOUNT1_SERVER):
        account1_history_data['error'] = f"Login failed for MT5 account {ACCOUNT1_NUMBER} for {ACCOUNT1_NAME}"
        terminal_logger.error(account1_history_data['error'])
    else:
        # Get both recent and historical data
        end_time = datetime.now()
        start_time = end_time - timedelta(days=365)  # Last 365 days

        # First get recent deals (last hour) to ensure we have latest trades
        recent_deals = mt5.history_deals_get(end_time - timedelta(hours=1), end_time)
        historical_deals = mt5.history_deals_get(start_time, end_time - timedelta(hours=1))
        
        all_deals = []
        if recent_deals is not None:
            all_deals.extend(recent_deals)
        if historical_deals is not None:
            all_deals.extend(historical_deals)

        if not all_deals:
            mt5.shutdown()
            account1_history_data['error'] = f"No deal history found for {ACCOUNT1_NAME}"
            terminal_logger.error(account1_history_data['error'])
        else:
            position_summary = defaultdict(lambda: {"ticket": None, "symbol": "", "type": None, "volume": None, "profit": 0, "commission": 0, "price": 0, "time": 0})
            for deal in all_deals:
                position_id = deal.position_id
                if position_summary[position_id]["ticket"] is None:
                    position_summary[position_id]["ticket"] = deal.ticket
                    position_summary[position_id]["volume"] = deal.volume
                position_summary[position_id]["symbol"] = deal.symbol
                position_summary[position_id]["type"] = deal.type
                position_summary[position_id]["profit"] += deal.profit
                position_summary[position_id]["commission"] += deal.commission
                position_summary[position_id]["price"] = deal.price
                # Use the most recent time for the position
                if deal.time > position_summary[position_id]["time"]:
                    position_summary[position_id]["time"] = deal.time

            trade_history = []
            for position_id, trade in position_summary.items():
                # Convert timestamp to local time
                local_time = datetime.fromtimestamp(trade["time"])
                trade_history.append({
                    "account_name": ACCOUNT1_NAME,
                    "account_number": ACCOUNT1_NUMBER,
                    "ticket": trade["ticket"],
                    "position_id": position_id,
                    "symbol": trade["symbol"],
                    "type": trade["type"],
                    "volume": trade["volume"],
                    "profit": round(trade["profit"], 2),
                    "commission": round(trade["commission"], 2),
                    "price": trade["price"],
                    "time": local_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "timestamp": trade["time"]  # Add raw timestamp for sorting
                })
            # Sort by timestamp in descending order (most recent first)
            account1_history = sorted(trade_history, key=lambda x: x["timestamp"], reverse=True)
            account1_history_data = account1_history
        mt5.shutdown()

    if "error" in account1_history_data:
        combined_history['account1_history_error'] = account1_history_data["error"]
        combined_history['account1_history'] = "Error retrieving history"
    else:
        combined_history['account1_history'] = account1_history_data

    # --- Account 2 History ---
    account2_history_data = {}
    if not mt5.initialize(path=ACCOUNT2_MT5_PATH):
        account2_history_data['error'] = f"Failed to connect to MT5 for {ACCOUNT2_NAME}"
        terminal_logger.error(account2_history_data['error'])
    elif not mt5.login(ACCOUNT2_NUMBER, ACCOUNT2_PASSWORD, ACCOUNT2_SERVER):
        account2_history_data['error'] = f"Login failed for MT5 account {ACCOUNT2_NUMBER} for {ACCOUNT2_NAME}"
        terminal_logger.error(account2_history_data['error'])
    else:
        # Get both recent and historical data
        end_time = datetime.now()
        start_time = end_time - timedelta(days=365)  # Last 365 days

        # First get recent deals (last hour) to ensure we have latest trades
        recent_deals = mt5.history_deals_get(end_time - timedelta(hours=1), end_time)
        historical_deals = mt5.history_deals_get(start_time, end_time - timedelta(hours=1))
        
        all_deals = []
        if recent_deals is not None:
            all_deals.extend(recent_deals)
        if historical_deals is not None:
            all_deals.extend(historical_deals)

        if not all_deals:
            mt5.shutdown()
            account2_history_data['error'] = f"No deal history found for {ACCOUNT2_NAME}"
            terminal_logger.error(account2_history_data['error'])
        else:
            position_summary = defaultdict(lambda: {"ticket": None, "symbol": "", "type": None, "volume": None, "profit": 0, "commission": 0, "price": 0, "time": 0})
            for deal in all_deals:
                position_id = deal.position_id
                if position_summary[position_id]["ticket"] is None:
                    position_summary[position_id]["ticket"] = deal.ticket
                    position_summary[position_id]["volume"] = deal.volume
                position_summary[position_id]["symbol"] = deal.symbol
                position_summary[position_id]["type"] = deal.type
                position_summary[position_id]["profit"] += deal.profit
                position_summary[position_id]["commission"] += deal.commission
                position_summary[position_id]["price"] = deal.price
                # Use the most recent time for the position
                if deal.time > position_summary[position_id]["time"]:
                    position_summary[position_id]["time"] = deal.time

            trade_history = []
            for position_id, trade in position_summary.items():
                # Convert timestamp to local time
                local_time = datetime.fromtimestamp(trade["time"])
                trade_history.append({
                    "account_name": ACCOUNT2_NAME,
                    "account_number": ACCOUNT2_NUMBER,
                    "ticket": trade["ticket"],
                    "position_id": position_id,
                    "symbol": trade["symbol"],
                    "type": trade["type"],
                    "volume": trade["volume"],
                    "profit": round(trade["profit"], 2),
                    "commission": round(trade["commission"], 2),
                    "price": trade["price"],
                    "time": local_time.strftime("%Y-%m-%d %H:%M:%S"),
                    "timestamp": trade["time"]  # Add raw timestamp for sorting
                })
            # Sort by timestamp in descending order (most recent first)
            account2_history = sorted(trade_history, key=lambda x: x["timestamp"], reverse=True)
            account2_history_data = account2_history
        mt5.shutdown()

    if "error" in account2_history_data:
        combined_history['account2_history_error'] = account2_history_data["error"]
        combined_history['account2_history'] = "Error retrieving history"
    else:
        combined_history['account2_history'] = account2_history_data

    # Add metadata about the request
    combined_history['metadata'] = {
        'request_time': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'data_timespan': '365 days',
        'includes_recent_trades': True
    }

    return jsonify(combined_history)

# -----------------------------------------------------------------------------
# Health Check Endpoint - NEW ENDPOINT with Swagger Documentation
# -----------------------------------------------------------------------------
@app.route('/health', methods=['GET'])
def health_check():
    """
    Endpoint to check MT5 connection health for both accounts.
    ---
    tags:
      - Monitoring
    summary: Checks the connection status of MT5 terminals for both Account 1 and Account 2.
    responses:
      200:
        description: Health status of MT5 connections for both accounts.
        content:
          application/json:
            schema:
              type: object
              properties:
                Account 1 (Main):
                  type: object
                  description: Health status for Account 1.
                Account 2 (Hedge):
                  type: object
                  description: Health status for Account 2.
    """
    account1_health = get_account_health(ACCOUNT1_NAME, ACCOUNT1_MT5_PATH)
    account2_health = get_account_health(ACCOUNT2_NAME, ACCOUNT2_MT5_PATH)
    combined_health = {**account1_health, **account2_health} # Merge dictionaries
    return jsonify(combined_health)

# -----------------------------------------------------------------------------
# Strategies Endpoint - NEW ENDPOINTS
# -----------------------------------------------------------------------------
@app.route('/strategies', methods=['GET'])
def get_strategies():
    """
    Get all stored strategies
    """
    strategies = get_all_strategies()
    return jsonify([{
        'id': s[0],
        'name': s[1],
        'start_time': s[2],
        'end_time': s[3],
        'initial_equity_acc1': s[4],
        'initial_equity_acc2': s[5],
        'final_equity_acc1': s[6],
        'final_equity_acc2': s[7],
        'target_percent': s[8],
        'stop_loss_percent': s[9],
        'status': s[10],
        'total_profit': s[11]
    } for s in strategies])

@app.route('/strategy/<int:strategy_id>', methods=['GET'])
def get_strategy(strategy_id):
    try:
        strategy, trades = get_strategy_details(strategy_id)
        
        if not strategy:
            return jsonify({'error': 'Strategy not found'}), 404
            
        try:
            # Convert strategy times to proper ISO format with error handling
            strategy_dict = {
                'id': strategy[0],
                'name': strategy[1],
                'start_time': None,
                'end_time': None,
                'initial_equity_acc1': strategy[4],
                'initial_equity_acc2': strategy[5],
                'final_equity_acc1': strategy[6],
                'final_equity_acc2': strategy[7],
                'target_percent': strategy[8],
                'stop_loss_percent': strategy[9],
                'status': strategy[10],
                'total_profit': strategy[11]
            }

            # Handle start time
            try:
                if strategy[2]:  # start_time
                    start_time = datetime.fromisoformat(strategy[2].replace('Z', '+00:00'))
                    strategy_dict['start_time'] = start_time.isoformat()
            except (ValueError, TypeError) as e:
                logger.error(f"Error parsing start time: {e}")
                strategy_dict['start_time'] = datetime.now().isoformat()

            # Handle end time
            try:
                if strategy[3]:  # end_time
                    end_time = datetime.fromisoformat(strategy[3].replace('Z', '+00:00'))
                    strategy_dict['end_time'] = end_time.isoformat()
                else:
                    strategy_dict['end_time'] = datetime.now().isoformat()
            except (ValueError, TypeError) as e:
                logger.error(f"Error parsing end time: {e}")
                strategy_dict['end_time'] = datetime.now().isoformat()

            # Ensure start_time is before end_time
            start = datetime.fromisoformat(strategy_dict['start_time'].replace('Z', '+00:00'))
            end = datetime.fromisoformat(strategy_dict['end_time'].replace('Z', '+00:00'))
            if start > end:
                strategy_dict['start_time'], strategy_dict['end_time'] = strategy_dict['end_time'], strategy_dict['start_time']
        
            # Get equity data for the strategy period
            equity_data = get_strategy_equity(strategy_id)
            
            # Process trades data
            processed_trades = []
            account1_stats = {
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'total_profit': 0,
                'max_drawdown': 0,
                'peak_equity': float(strategy_dict['initial_equity_acc1'] or 0),
                'max_winning_streak': 0,
                'max_losing_streak': 0
            }
            
            account2_stats = {
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'total_profit': 0,
                'max_drawdown': 0,
                'peak_equity': float(strategy_dict['initial_equity_acc2'] or 0),
                'max_winning_streak': 0,
                'max_losing_streak': 0
            }

            # Process trades and calculate statistics
            for trade in trades:
                try:
                    trade_time = None
                    if isinstance(trade[9], str):
                        trade_time = datetime.fromisoformat(trade[9].replace('Z', '+00:00')).isoformat()
                    elif isinstance(trade[9], (int, float)):
                        trade_time = datetime.fromtimestamp(trade[9]).isoformat()
                    else:
                        trade_time = datetime.now().isoformat()

                    trade_dict = {
                        'id': trade[0],
                        'account_number': trade[2],
                        'ticket': trade[3],
                        'symbol': trade[4],
                        'type': trade[5],
                        'volume': float(trade[6]) if trade[6] is not None else 0.0,
                        'price': float(trade[7]) if trade[7] is not None else 0.0,
                        'profit': float(trade[8]) if trade[8] is not None else 0.0,
                        'time': trade_time
                    }
                    processed_trades.append(trade_dict)
                    
                    # Update account statistics - only for Buy (0) and Sell (1) trades
                    if trade_dict['type'] in [0, 1]:  # Only consider Buy and Sell trades
                        stats = account1_stats if trade_dict['account_number'] == ACCOUNT1_NUMBER else account2_stats
                        stats['total_trades'] += 1
                        if trade_dict['profit'] > 0:
                            stats['winning_trades'] += 1
                        else:
                            stats['losing_trades'] += 1
                        stats['total_profit'] += trade_dict['profit']
                except Exception as e:
                    logger.error(f"Error processing trade: {e}")
                    continue

            # Calculate win rates
            for stats in [account1_stats, account2_stats]:
                if stats['total_trades'] > 0:
                    stats['win_rate'] = (stats['winning_trades'] / stats['total_trades']) * 100
                else:
                    stats['win_rate'] = 0

            # Process equity series data with error handling
            equity_series = {
                'timestamps': [],
                'account1': [],
                'account2': [],
                'combined': []
            }

            for entry in equity_data:
                try:
                    timestamp = None
                    if isinstance(entry[0], str):
                        timestamp = datetime.fromisoformat(entry[0].replace('Z', '+00:00')).isoformat()
                    elif isinstance(entry[0], (int, float)):
                        timestamp = datetime.fromtimestamp(entry[0]).isoformat()
                    else:
                        continue

                    acc1_equity = float(entry[1]) if entry[1] is not None else 0.0
                    acc2_equity = float(entry[2]) if entry[2] is not None else 0.0

                    equity_series['timestamps'].append(timestamp)
                    equity_series['account1'].append(acc1_equity)
                    equity_series['account2'].append(acc2_equity)
                    equity_series['combined'].append(acc1_equity + acc2_equity)
                except Exception as e:
                    logger.error(f"Error processing equity data point: {e}")
                    continue

            return jsonify({
                'strategy': strategy_dict,
                'trades': processed_trades,
                'statistics': {
                    'account1': account1_stats,
                    'account2': account2_stats
                },
                'equity_series': equity_series
            })

        except Exception as e:
            logger.exception("Error processing strategy data")
            return jsonify({'error': f'Error processing strategy data: {str(e)}'}), 500

    except Exception as e:
        logger.exception("Error fetching strategy details")
        return jsonify({'error': f'Error fetching strategy details: {str(e)}'}), 500

# Add these new endpoints
@app.route('/start_strategy', methods=['POST'])
def start_strategy():
    """
    Start a new strategy and store initial data
    """
    try:
        global current_strategy_id  # Add this line
        logger.info("📬 Received start_strategy request headers: %s", request.headers)
        data = request.get_json()
        logger.info("📦 Request data: %s", data)
        
        if not data:
            logger.error("No data provided in request")
            return jsonify({'error': 'No data provided'}), 400

        required_fields = ['target_percent', 'stop_loss_percent', 
                         'initial_equity_acc1', 'initial_equity_acc2']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            logger.error(f"Missing fields in request: {missing_fields}")
            return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400

        strategy_id = store_strategy(
            start_time=datetime.now(),
            initial_equity_acc1=data.get('initial_equity_acc1'),
            initial_equity_acc2=data.get('initial_equity_acc2'),
            target_percent=data.get('target_percent'),
            stop_loss_percent=data.get('stop_loss_percent')
        )
        current_strategy_id = strategy_id  # Set the global variable
        logger.debug(f"Strategy created with ID: {strategy_id}")
        return jsonify({'strategy_id': strategy_id, 'status': 'success'})
    except Exception as e:
        logger.exception("🔥 Critical error in start_strategy")
        return jsonify({
            'error': 'Internal server error',
            'details': str(e)
        }), 500

@app.route('/stop_strategy', methods=['POST'])
def stop_strategy():
    try:
        global current_strategy_id  # Add this line
        data = request.json
        if not data or 'strategy_id' not in data:
            return jsonify({'error': 'Invalid request'}), 400

        strategy_id = data['strategy_id']
        
        # Get initial equity values
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''
                SELECT initial_equity_acc1, initial_equity_acc2 
                FROM strategies 
                WHERE id = ?
            ''', (strategy_id,))
            result = c.fetchone()

        if not result:
            return jsonify({'error': 'Strategy not found'}), 404

        initial_acc1, initial_acc2 = result
        final_acc1 = data.get('final_equity_acc1', 0)
        final_acc2 = data.get('final_equity_acc2', 0)
        
        # Calculate actual profit
        total_profit = (final_acc1 - initial_acc1) + (final_acc2 - initial_acc2)

        # Update strategy
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''
                UPDATE strategies SET
                    end_time = ?,
                    final_equity_acc1 = ?,
                    final_equity_acc2 = ?,
                    total_profit = ?,
                    status = 'completed'
                WHERE id = ?
            ''', (
                datetime.now(),
                final_acc1,
                final_acc2,
                total_profit,
                strategy_id
            ))

        current_strategy_id = None  # Clear the global variable
        return jsonify({'success': True})

    except Exception as e:
        logger.exception("Stop strategy error")
        return jsonify({'error': str(e)}), 500

@app.route('/strategy/<int:strategy_id>/rename', methods=['POST'])
def rename_strategy(strategy_id):
    """
    Rename a strategy
    ---
    parameters:
      - name: strategy_id
        in: path
        type: integer
        required: true
      - name: name
        in: body
        type: string
        required: true
    responses:
      200:
        description: Strategy renamed successfully
      404:
        description: Strategy not found
      400:
        description: Invalid request
    """
    try:
        data = request.get_json()
        if not data or 'name' not in data:
            return jsonify({'error': 'Name is required'}), 400
            
        new_name = data['name'].strip()
        if not new_name:
            return jsonify({'error': 'Name cannot be empty'}), 400
            
        update_strategy_name(strategy_id, new_name)
        return jsonify({'message': 'Strategy renamed successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Initialize database when app starts
init_db()

# Add this error handler before your routes
@app.errorhandler(Exception)
def handle_error(error):
    code = 500
    if isinstance(error, HTTPException):
        code = error.code
    return jsonify({
        'error': str(error),
        'status_code': code
    }), code

# Add error handler for 404
@app.errorhandler(404)
def handle_404_error(error):
    return jsonify({'error': 'Resource not found'}), 404

def get_strategy_details(strategy_id):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            
            # Get strategy details
            c.execute('SELECT * FROM strategies WHERE id = ?', (strategy_id,))
            strategy = c.fetchone()
            
            if not strategy:
                return None, None

            all_trades = []
            
            # Get position history for both accounts
            try:
                # Initialize MT5 for Account 1
                if mt5.initialize(path=ACCOUNT1_MT5_PATH):
                    if mt5.login(ACCOUNT1_NUMBER, ACCOUNT1_PASSWORD, ACCOUNT1_SERVER):
                        # Get all deals history for Account 1 without time filtering
                        deals = mt5.history_deals_get()
                        if deals:
                            logger.info(f"Found {len(deals)} deals for Account 1")
                            for deal in deals:
                                # Convert deal time to IST
                                deal_time_utc = datetime.fromtimestamp(deal.time, UTC)
                                deal_time_ist = deal_time_utc.astimezone(IST)
                                
                                logger.info(f"Account 1 Deal: Ticket={deal.ticket}, Time={deal_time_ist.strftime('%Y-%m-%d %H:%M:%S')}, Profit={deal.profit}")
                                
                                # Store trade in database
                                c.execute('''
                                    INSERT OR REPLACE INTO trades (
                                        strategy_id, account_number, ticket, symbol,
                                        type, volume, price, profit, time
                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ''', (
                                    strategy_id,
                                    deal.login,
                                    deal.ticket,
                                    deal.symbol,
                                    deal.type,
                                    deal.volume,
                                    deal.price,
                                    deal.profit,
                                    deal_time_ist.strftime("%Y-%m-%d %H:%M:%S")
                                ))
                                
                                trade_record = (
                                    None,  # id
                                    strategy_id,
                                    deal.login,  # account_number
                                    deal.ticket,
                                    deal.symbol,
                                    deal.type,
                                    deal.volume,
                                    deal.price,
                                    deal.profit,
                                    deal_time_ist.strftime("%Y-%m-%d %H:%M:%S IST")
                                )
                                all_trades.append(trade_record)
                        else:
                            logger.info(f"No deals found for Account 1. MT5 Error: {mt5.last_error()}")
                    mt5.shutdown()

                # Initialize MT5 for Account 2
                if mt5.initialize(path=ACCOUNT2_MT5_PATH):
                    if mt5.login(ACCOUNT2_NUMBER, ACCOUNT2_PASSWORD, ACCOUNT2_SERVER):
                        # Get all deals history for Account 2 without time filtering
                        deals = mt5.history_deals_get()
                        if deals:
                            logger.info(f"Found {len(deals)} deals for Account 2")
                            for deal in deals:
                                # Convert deal time to IST
                                deal_time_utc = datetime.fromtimestamp(deal.time, UTC)
                                deal_time_ist = deal_time_utc.astimezone(IST)
                                
                                logger.info(f"Account 2 Deal: Ticket={deal.ticket}, Time={deal_time_ist.strftime('%Y-%m-%d %H:%M:%S')}, Profit={deal.profit}")
                                
                                # Store trade in database
                                c.execute('''
                                    INSERT OR REPLACE INTO trades (
                                        strategy_id, account_number, ticket, symbol,
                                        type, volume, price, profit, time
                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                                ''', (
                                    strategy_id,
                                    deal.login,
                                    deal.ticket,
                                    deal.symbol,
                                    deal.type,
                                    deal.volume,
                                    deal.price,
                                    deal.profit,
                                    deal_time_ist.strftime("%Y-%m-%d %H:%M:%S")
                                ))
                                
                                trade_record = (
                                    None,  # id
                                    strategy_id,
                                    deal.login,  # account_number
                                    deal.ticket,
                                    deal.symbol,
                                    deal.type,
                                    deal.volume,
                                    deal.price,
                                    deal.profit,
                                    deal_time_ist.strftime("%Y-%m-%d %H:%M:%S IST")
                                )
                                all_trades.append(trade_record)
                        else:
                            logger.info(f"No deals found for Account 2. MT5 Error: {mt5.last_error()}")
                    mt5.shutdown()

                conn.commit()
            except Exception as e:
                logger.exception("Error fetching trades")
                
            logger.info(f"Total trades found: {len(all_trades)}")
            return strategy, all_trades
            
    except Exception as e:
        logger.exception("Error in get_strategy_details")
        return None, None

# Add this new endpoint
@app.route('/tradinglogs')
def get_trading_logs():
    try:
        # Update paths to match your actual log files
        general_log_path = "general_log.txt"    # Changed from general.log
        trading_log_path = "orders_log.txt"     # Changed from trading.log
        terminal_log_path = "terminal_log.txt"  # Changed from terminal.log

        logs = {
            'general_logs': [],
            'trading_logs': [],
            'terminal_logs': []
        }

        # Function to read last 10 lines from a file
        def read_last_lines(file_path, n=10):
            try:
                with open(file_path, 'r') as file:
                    # Read all lines and get last n lines
                    lines = file.readlines()
                    return [line.strip() for line in (lines[-n:] if len(lines) > n else lines)]
            except Exception as e:
                logger.error(f"Error reading log file {file_path}: {str(e)}")
                return []

        # Get logs from each file
        logs['general_logs'] = read_last_lines(general_log_path)
        logs['trading_logs'] = read_last_lines(trading_log_path)
        logs['terminal_logs'] = read_last_lines(terminal_log_path)

        return jsonify(logs)

    except Exception as e:
        logger.exception("Error fetching logs")
        return jsonify({
            'error': 'Failed to fetch logs',
            'message': str(e)
        }), 500

if __name__ == '__main__':
    print("🔄 Starting Flask server...")
    print(f"🔍 Database path: {os.path.abspath('strategy.db')}")
    app.run(host='0.0.0.0', port=5000, debug=True)