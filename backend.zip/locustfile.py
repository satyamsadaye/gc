from locust import HttpUser, task, between
import random
import json

class TradingWebhookUser(HttpUser):
    host = "http://localhost:5000"  # Set the base host
    # Wait between 1 to 5 seconds between tasks by default
    wait_time = between(1, 5)
    
    @task
    def send_trading_webhook(self):
        # Randomly choose between buy and sell
        action_type = random.choice(["ORDER_TYPE_BUY", "ORDER_TYPE_SELL"])
        
        # Generate random ATR between 0.3 and 6.0
        atr = round(random.uniform(0.3, 6.0), 2)
        
        payload = {
            "actionType": action_type,
            "symbol": "XAUUSD",
            "atr": atr,
            "comment": "Locust Load Test"
        }
        
        headers = {'Content-Type': 'application/json'}
        self.client.post("/webhook", json=payload, headers=headers) 