import os
import sqlite3
from datetime import datetime

# Temporarily change DB path to absolute location
DB_PATH = r'E:\Satyam Trading\Trading Dashboard\Working State Projects\Seperate Realtime Strategy Test Everything is working 19 Feb 25 11.30 PM\Seperate Realtime Strategy Test Everything is working 19 Feb 25 11.30 PM\backend\strategy.db'

def init_db():
    print(f"🛠️ Initializing database at: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Create strategies table
    c.execute('''
        CREATE TABLE IF NOT EXISTS strategies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT DEFAULT 'Untitled Strategy',
            start_time TIMESTAMP,
            end_time TIMESTAMP,
            initial_equity_acc1 REAL,
            initial_equity_acc2 REAL,
            final_equity_acc1 REAL,
            final_equity_acc2 REAL,
            target_percent REAL,
            stop_loss_percent REAL,
            status TEXT,
            total_profit REAL
        )
    ''')
    
    # Create trades table with additional fields
    c.execute('''
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy_id INTEGER,
            account_number INTEGER,
            ticket INTEGER,
            symbol TEXT,
            type TEXT,
            volume REAL,
            price REAL,
            profit REAL,
            time TIMESTAMP,
            status TEXT DEFAULT 'open',
            close_price REAL,
            close_time TIMESTAMP,
            FOREIGN KEY (strategy_id) REFERENCES strategies (id)
        )
    ''')
    
    # Add strategy equity table
    c.execute('''
        CREATE TABLE IF NOT EXISTS strategy_equity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy_id INTEGER,
            timestamp TIMESTAMP,
            account1_equity REAL,
            account2_equity REAL,
            FOREIGN KEY (strategy_id) REFERENCES strategies (id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database tables created successfully")

def store_strategy(start_time, initial_equity_acc1, initial_equity_acc2, target_percent, stop_loss_percent):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Store the start time in ISO format
    start_time_iso = start_time.isoformat()
    
    c.execute('''
        INSERT INTO strategies (
            start_time, initial_equity_acc1, initial_equity_acc2,
            target_percent, stop_loss_percent, status
        ) VALUES (?, ?, ?, ?, ?, ?)
    ''', (start_time_iso, initial_equity_acc1, initial_equity_acc2,
          target_percent, stop_loss_percent, 'running'))
    
    strategy_id = c.lastrowid
    conn.commit()
    conn.close()
    return strategy_id

def update_strategy_end(strategy_id, end_time, final_equity_acc1, final_equity_acc2, total_profit):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get the start time
    c.execute('SELECT start_time FROM strategies WHERE id = ?', (strategy_id,))
    result = c.fetchone()
    if result:
        start_time = datetime.fromisoformat(result[0])
        end_time_dt = end_time if isinstance(end_time, datetime) else datetime.fromisoformat(end_time)
        
        # Ensure end_time is after start_time
        if end_time_dt < start_time:
            end_time_dt, start_time = start_time, end_time_dt
            # Update the start time as well
            c.execute('''
                UPDATE strategies
                SET start_time = ?
                WHERE id = ?
            ''', (start_time.isoformat(), strategy_id))
    
    c.execute('''
        UPDATE strategies
        SET end_time = ?, final_equity_acc1 = ?, final_equity_acc2 = ?, 
            total_profit = ?, status = 'completed'
        WHERE id = ?
    ''', (end_time_dt.isoformat(), final_equity_acc1, final_equity_acc2, total_profit, strategy_id))
    
    conn.commit()
    conn.close()

def store_trade(strategy_id, account_number, ticket, symbol, trade_type, 
                volume, price, profit, trade_time):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    try:
        # Convert timestamp to datetime if needed
        if isinstance(trade_time, (int, float)):
            trade_time = datetime.fromtimestamp(trade_time)
        
        # Check if trade already exists
        c.execute('''
            SELECT id FROM trades 
            WHERE strategy_id = ? AND account_number = ? AND ticket = ?
        ''', (strategy_id, account_number, ticket))
        
        existing_trade = c.fetchone()
        
        if existing_trade:
            # Update existing trade
            if trade_type == "CLOSE":
                c.execute('''
                    UPDATE trades 
                    SET status = 'closed',
                        close_price = ?,
                        close_time = ?,
                        profit = ?
                    WHERE strategy_id = ? AND account_number = ? AND ticket = ?
                ''', (price, trade_time.isoformat(), profit, strategy_id, account_number, ticket))
            else:
                c.execute('''
                    UPDATE trades 
                    SET profit = ?
                    WHERE strategy_id = ? AND account_number = ? AND ticket = ?
                ''', (profit, strategy_id, account_number, ticket))
        else:
            # Insert new trade
            c.execute('''
                INSERT INTO trades (
                    strategy_id, account_number, ticket, symbol,
                    type, volume, price, profit, time, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (strategy_id, account_number, ticket, symbol, trade_type,
                  volume, price, profit, trade_time.isoformat(), 
                  'closed' if trade_type == "CLOSE" else 'open'))
        
        conn.commit()
        print(f"Trade stored/updated successfully: Strategy={strategy_id}, Account={account_number}, Ticket={ticket}")
    except Exception as e:
        print(f"Error storing trade: {e}")
        raise
    finally:
        conn.close()

def get_all_strategies():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute('''
        SELECT * FROM strategies ORDER BY start_time DESC
    ''')
    strategies = c.fetchall()
    conn.close()
    return strategies

def get_strategy_details(strategy_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get strategy info
    c.execute('SELECT * FROM strategies WHERE id = ?', (strategy_id,))
    strategy = c.fetchone()
    
    if strategy:
        try:
            # Get all trades within the strategy's time period
            start_time = datetime.fromisoformat(strategy[2])
            end_time = datetime.fromisoformat(strategy[3]) if strategy[3] else datetime.now()
            
            # Ensure start_time is before end_time
            if start_time > end_time:
                start_time, end_time = end_time, start_time
            
            # Get trades within the strategy period
            c.execute('''
                SELECT * FROM trades 
                WHERE strategy_id = ? 
                AND datetime(time) BETWEEN datetime(?) AND datetime(?)
                ORDER BY time DESC
            ''', (strategy_id, start_time.isoformat(), end_time.isoformat()))
            trades = c.fetchall()
            
            # Log for debugging
            print(f"Found {len(trades)} trades for strategy {strategy_id}")
            print(f"Strategy period: {start_time.isoformat()} to {end_time.isoformat()}")
            for trade in trades:
                print(f"Trade: {trade}")
        except Exception as e:
            print(f"Error getting trades: {e}")
            trades = []
    else:
        trades = []
    
    conn.close()
    return strategy, trades

def get_strategy_equity(strategy_id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Get strategy time period
    c.execute('SELECT start_time, end_time FROM strategies WHERE id = ?', (strategy_id,))
    strategy_times = c.fetchone()
    
    if strategy_times:
        start_time = datetime.fromisoformat(strategy_times[0])
        end_time = datetime.fromisoformat(strategy_times[1]) if strategy_times[1] else datetime.now()
        
        # Ensure start_time is before end_time
        if start_time > end_time:
            start_time, end_time = end_time, start_time
        
        # Get equity data within the strategy's time period
        c.execute('''
            SELECT timestamp, account1_equity, account2_equity 
            FROM strategy_equity 
            WHERE strategy_id = ?
            AND datetime(timestamp) BETWEEN datetime(?) AND datetime(?)
            ORDER BY timestamp
        ''', (strategy_id, start_time.isoformat(), end_time.isoformat()))
        equity_data = c.fetchall()
    else:
        equity_data = []
    
    conn.close()
    return equity_data

def update_strategy_name(strategy_id, new_name):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    c.execute('''
        UPDATE strategies
        SET name = ?
        WHERE id = ?
    ''', (new_name, strategy_id))
    
    conn.commit()
    conn.close() 